# Library Management System
--------------------------
+ A simple library management system for making the life of librarians and its user easy and cool.
+ This project is made in C++ using many concepts of C++.
